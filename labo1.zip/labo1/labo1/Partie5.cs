﻿using System;
using System.Collections.Generic;//Поскольку нам нужно удалять элементы из списка, а массивы не позволяют удаление, 
                                 //для хранения данных используем класс List из библиотеки System.Collections.Generic.


class partie5
{
    public void GetInfo3()
    {
        Console.Write("N = ");
        var n = Convert.ToUInt32(Console.ReadLine());
        var primeNumbers = SieveEratosthenes(n);//функция, позволяющая найти все простые числа до заданного предела.
        Console.WriteLine("Простые числа до заданного {0}:", n);
        Console.WriteLine(string.Join(", ", primeNumbers));
        Console.ReadLine();

        // //возвращает список простых чисел
        static List<uint> SieveEratosthenes(uint n)
        {
            var numbers = new List<uint>();
            //заполнение списка числами от 2 до n-1
            for (var i = 2u; i < n; i++)
            {
                numbers.Add(i);
            }

            for (var i = 0; i < numbers.Count; i++)
            {
                for (var j = 2u; j < n; j++)
                {
                    //удаляем кратные числа из списка
                    numbers.Remove(numbers[i] * j);
                }
            }

            return numbers;
        }
    }
}
