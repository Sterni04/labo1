﻿using System;

/* 3.Вывести последовательность чисел Фибоначи */
class partie3
{
    public void GetInfo1()
    {
        int nombre;
        int prevnbr = 1;
        int nextnbr = 1;
        int result;

        Console.WriteLine("Enter a number");
        nombre = int.Parse(Console.ReadLine());

        Console.WriteLine(prevnbr);
        Console.WriteLine(nextnbr);

        for (int i = 2; i < nombre; i++)
        {
            result = prevnbr + nextnbr;
            Console.WriteLine(result);
            prevnbr = nextnbr;
            nextnbr = result;
        }

    }
}