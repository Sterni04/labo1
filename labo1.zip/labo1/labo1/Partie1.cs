﻿using System;

 class partie1
{
	public void GetInfo4(string[] tab)
	{
        if (tab.Length <= 0)
        {
            Console.WriteLine("Аргументов не найдено");
        }

        else
        {
            for(int i = 0; i < tab.Length; i++)
            {
             Console.WriteLine("аргумент: " + i + " - " + tab[i]);
            }
        }
	}
}
