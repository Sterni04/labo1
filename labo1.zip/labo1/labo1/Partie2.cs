﻿using System;

/* 2.Распечатать лет с 1900 по 2000. */
class partie2
{
    public void GetInfo()
    {
        int i = 0;

        for (i = 1900; i <= 2000; i++)
        {
            //мы проверяем, делится ли i на 400 или делится ли i на 4 и не делится на 100
            if ((i % 400 == 0) || (i % 4 == 0 && i % 100 != 0))
            {
                Console.WriteLine(i + " Високосный");
            }

            else
            {
                Console.WriteLine(i + " Не високосный");
            }
        }
    }
}

