﻿using System;

namespace labo1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;

            Console.WriteLine("********************МЕНЮ********************");
            Console.WriteLine("1.Вывести на экран аргументы, переданные в программу при запуске в командной строке.");
            Console.WriteLine("2.Распечатать лет с 1900 по 2000");
            Console.WriteLine("3.Вывести последовательность чисел Фибоначи до заданного числа.");
            Console.WriteLine("4.Вычислить факториал заданного числа.");
            Console.WriteLine("5.Вывести все простые числа не превышающие заданное. Для решения использовать алгоритм «решето Эратосфена».");
            Console.WriteLine("0.Exit");
            Console.WriteLine("********************************************");

            Console.WriteLine("Choose a number");
            a = int.Parse(Console.ReadLine());

            while (a != 0)
            {
                if (a == 1)
                {
                    partie1 element = new partie1();
                    element.GetInfo4(args);
                }


                else if (a == 2)
                {
                    //создание объекта element1
                    partie2 element1 = new partie2();
                    //вызов метода GetInfo в классе partie2
                    element1.GetInfo();
                }


                else if (a == 3)
                {
                    partie3 elemet2 = new partie3();
                    elemet2.GetInfo1();
                }


                else if (a == 4)
                {
                    partie4 element3 = new partie4();
                    element3.GetInfo2();
                }


                else if (a == 5)
                {
                    partie5 element5 = new partie5();
                    element5.GetInfo3();
                }


                else
                {
                    Console.WriteLine("ERROR");
                }

                Console.WriteLine("********************МЕНЮ********************");
                Console.WriteLine("2.Распечатать лет с 1900 по 2000");
                Console.WriteLine("3.Вывести последовательность чисел Фибоначи до заданного числа.");
                Console.WriteLine("4.Вычислить факториал заданного числа.");
                Console.WriteLine("5.Вывести все простые числа не превышающие заданное. Для решения использовать алгоритм «решето Эратосфена».");
                Console.WriteLine("0.Exit");
                Console.WriteLine("********************************************");

                Console.WriteLine("Choose a number");
                a = int.Parse(Console.ReadLine());
            }



        }
    }
}
