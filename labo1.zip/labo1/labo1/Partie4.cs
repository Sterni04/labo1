﻿using System;

/* 4.Вычислить факториал заданного числа. */
class partie4
{
    public void GetInfo2()
    {
        
        int chiffre;

        Console.WriteLine("Enter a number");
        chiffre = int.Parse(Console.ReadLine());

        int result = 1;

        for (int i = 1; i <= chiffre; i++)
        {
            result *= i;

        }

        Console.WriteLine(chiffre + "! = " + result);
    }

}


